"use client"

import { useState } from "react"
import { CheckCircle2, Circle, ArrowLeft, ArrowRight, RotateCcw, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface AssessmentSectionProps {
  onComplete: (level: number) => void
}

interface Question {
  id: number
  text: string
  options: { id: string; text: string; score: number }[]
}

const questions: Question[] = [
  {
    id: 1,
    text: "عندما يُطلب منك تخيل تفاحة حمراء، ما مدى وضوح الصورة في ذهنك؟",
    options: [
      { id: "a", text: "واضحة جداً كأنني أراها أمامي", score: 5 },
      { id: "b", text: "واضحة نسبياً مع بعض التفاصيل", score: 4 },
      { id: "c", text: "غامضة وضبابية", score: 3 },
      { id: "d", text: "أعرف أنها تفاحة لكن لا أرى صورة", score: 2 },
      { id: "e", text: "لا أستطيع تخيل أي صورة على الإطلاق", score: 1 },
    ],
  },
  {
    id: 2,
    text: "كيف تتذكر وجه صديق مقرب لم تره منذ فترة؟",
    options: [
      { id: "a", text: "أستطيع رؤية وجهه بوضوح في ذهني", score: 5 },
      { id: "b", text: "أتذكر ملامحه الأساسية بشكل عام", score: 4 },
      { id: "c", text: "أتذكر صفاته لكن الصورة غير واضحة", score: 3 },
      { id: "d", text: "أتذكر معلومات عنه دون صورة", score: 2 },
      { id: "e", text: "لا أستطيع استحضار أي صورة ذهنية", score: 1 },
    ],
  },
  {
    id: 3,
    text: "عند قراءة رواية، هل تتخيل المشاهد والشخصيات؟",
    options: [
      { id: "a", text: "نعم، كأنني أشاهد فيلماً في ذهني", score: 5 },
      { id: "b", text: "أحياناً أتخيل بعض المشاهد", score: 4 },
      { id: "c", text: "نادراً ما أتخيل صوراً واضحة", score: 3 },
      { id: "d", text: "أفهم القصة دون تخيل بصري", score: 2 },
      { id: "e", text: "لا أتخيل أي شيء على الإطلاق", score: 1 },
    ],
  },
  {
    id: 4,
    text: "كيف تخطط ليومك أو لمهامك؟",
    options: [
      { id: "a", text: "أستطيع التخطيط بسهولة وتنفيذ الخطة", score: 5 },
      { id: "b", text: "أخطط جيداً لكن أحياناً أنسى بعض المهام", score: 4 },
      { id: "c", text: "أحتاج إلى تذكيرات وقوائم مكتوبة", score: 3 },
      { id: "d", text: "أجد صعوبة في التخطيط المسبق", score: 2 },
      { id: "e", text: "التخطيط صعب جداً بالنسبة لي", score: 1 },
    ],
  },
  {
    id: 5,
    text: "عند العمل على مهمة طويلة، كيف تحافظ على تركيزك؟",
    options: [
      { id: "a", text: "أستطيع التركيز لفترات طويلة بسهولة", score: 5 },
      { id: "b", text: "أحتاج إلى فترات راحة قصيرة", score: 4 },
      { id: "c", text: "أشتت بسهولة لكن أعود للمهمة", score: 3 },
      { id: "d", text: "أجد صعوبة كبيرة في الحفاظ على التركيز", score: 2 },
      { id: "e", text: "لا أستطيع التركيز لفترات طويلة أبداً", score: 1 },
    ],
  },
  {
    id: 6,
    text: "كيف تتعامل مع التعليمات المتعددة الخطوات؟",
    options: [
      { id: "a", text: "أتذكرها وأنفذها بالترتيب بسهولة", score: 5 },
      { id: "b", text: "أتذكر معظمها مع بعض الأخطاء", score: 4 },
      { id: "c", text: "أحتاج إلى كتابتها أو تكرارها", score: 3 },
      { id: "d", text: "أنسى الخطوات بسرعة", score: 2 },
      { id: "e", text: "أجد صعوبة شديدة في تتبع التعليمات", score: 1 },
    ],
  },
  {
    id: 7,
    text: "عند مواجهة مشكلة جديدة، كيف تفكر في الحلول؟",
    options: [
      { id: "a", text: "أستطيع تصور حلول متعددة بسرعة", score: 5 },
      { id: "b", text: "أفكر في خيارات ثم أختار الأنسب", score: 4 },
      { id: "c", text: "أحتاج وقتاً للتفكير في الحلول", score: 3 },
      { id: "d", text: "أعتمد على تجارب سابقة مشابهة", score: 2 },
      { id: "e", text: "أجد صعوبة في إيجاد الحلول بمفردي", score: 1 },
    ],
  },
]

function calculateLevel(score: number): number {
  const maxScore = questions.length * 5
  const percentage = (score / maxScore) * 100

  if (percentage >= 80) return 5
  if (percentage >= 60) return 4
  if (percentage >= 40) return 3
  if (percentage >= 20) return 2
  return 1
}

function getLevelInfo(level: number): { title: string; description: string; color: string } {
  const levels = {
    1: {
      title: "المستوى الأول - البناء الأساسي",
      description: "تحتاج إلى دعم مكثف مع استراتيجيات بديلة للتخيل البصري. سنبدأ معك من الأساسيات مع أدوات مساعدة متعددة.",
      color: "bg-primary",
    },
    2: {
      title: "المستوى الثاني - البناء المتدرج",
      description: "لديك بعض القدرات الأساسية. سنعمل على تعزيزها مع تقديم استراتيجيات بديلة عند الحاجة.",
      color: "bg-primary/80",
    },
    3: {
      title: "المستوى الثالث - البناء المتوسط",
      description: "قدراتك المعرفية في المستوى المتوسط. سنركز على تطوير نقاط القوة ومعالجة التحديات.",
      color: "bg-secondary",
    },
    4: {
      title: "المستوى الرابع - البناء المتقدم",
      description: "لديك قدرات معرفية جيدة. سنعمل على صقلها وتوسيع مهاراتك.",
      color: "bg-secondary/80",
    },
    5: {
      title: "المستوى الخامس - البناء المتميز",
      description: "قدراتك المعرفية متميزة! سنقدم لك تحديات متقدمة وفرص لتطوير مهاراتك أكثر.",
      color: "bg-accent",
    },
  }
  return levels[level as keyof typeof levels]
}

export function AssessmentSection({ onComplete }: AssessmentSectionProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [showResult, setShowResult] = useState(false)
  const [resultLevel, setResultLevel] = useState(0)

  const progress = ((currentQuestion + 1) / questions.length) * 100
  const question = questions[currentQuestion]
  const selectedAnswer = answers[question.id]

  const handleSelectAnswer = (optionId: string) => {
    setAnswers({ ...answers, [question.id]: optionId })
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = () => {
    const totalScore = questions.reduce((sum, q) => {
      const selectedOption = q.options.find((o) => o.id === answers[q.id])
      return sum + (selectedOption?.score || 0)
    }, 0)

    const level = calculateLevel(totalScore)
    setResultLevel(level)
    setShowResult(true)
  }

  const handleReset = () => {
    setCurrentQuestion(0)
    setAnswers({})
    setShowResult(false)
    setResultLevel(0)
  }

  const handleViewLevel = () => {
    onComplete(resultLevel)
  }

  const allAnswered = Object.keys(answers).length === questions.length
  const isLastQuestion = currentQuestion === questions.length - 1

  if (showResult) {
    const levelInfo = getLevelInfo(resultLevel)
    return (
      <section className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <Card className="border-2 border-primary/20 overflow-hidden">
            <div className={`${levelInfo.color} p-6 text-center`}>
              <Award className="w-16 h-16 text-primary-foreground mx-auto mb-4" />
              <h2 className="font-[var(--font-heading)] text-2xl sm:text-3xl font-bold text-primary-foreground">
                نتيجة التقييم
              </h2>
            </div>
            <CardContent className="p-6 sm:p-8">
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-4">
                  <span className="font-[var(--font-heading)] text-4xl font-bold text-primary">
                    {resultLevel}
                  </span>
                </div>
                <h3 className="font-[var(--font-heading)] text-xl font-bold text-foreground mb-2">
                  {levelInfo.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {levelInfo.description}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="flex-1 gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  إعادة التقييم
                </Button>
                <Button
                  onClick={handleViewLevel}
                  className="flex-1 gap-2 bg-primary hover:bg-primary/90"
                >
                  استعراض المستويات
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    )
  }

  return (
    <section className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="font-[var(--font-heading)] text-3xl sm:text-4xl font-bold text-primary mb-4">
            التقييم المعرفي
          </h1>
          <p className="text-muted-foreground">
            أجب على الأسئلة التالية لتحديد مستواك المعرفي
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>السؤال {currentQuestion + 1} من {questions.length}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="font-[var(--font-heading)] text-xl leading-relaxed">
              {question.text}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {question.options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => handleSelectAnswer(option.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right ${
                    selectedAnswer === option.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/30 hover:bg-muted/50"
                  }`}
                  aria-pressed={selectedAnswer === option.id}
                >
                  {selectedAnswer === option.id ? (
                    <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0" />
                  ) : (
                    <Circle className="w-6 h-6 text-muted-foreground flex-shrink-0" />
                  )}
                  <span className="text-foreground leading-relaxed">{option.text}</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between gap-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            السابق
          </Button>

          {isLastQuestion ? (
            <Button
              onClick={handleSubmit}
              disabled={!allAnswered}
              className="gap-2 bg-primary hover:bg-primary/90"
            >
              إرسال الإجابات
              <CheckCircle2 className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              onClick={handleNext}
              disabled={!selectedAnswer}
              className="gap-2 bg-primary hover:bg-primary/90"
            >
              التالي
              <ArrowLeft className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </section>
  )
}
