"use client"

import { ArrowRight, BookOpen, CheckCircle2, Clock, Blocks } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface CurriculumSectionProps {
  onBack: () => void
}

const lessons = [
  {
    id: 1,
    title: "مقدمة في التعلم التكيفي",
    duration: "15 دقيقة",
    completed: false,
  },
  {
    id: 2,
    title: "فهم أنماط التفكير المختلفة",
    duration: "20 دقيقة",
    completed: false,
  },
  {
    id: 3,
    title: "استراتيجيات بديلة للتخيل البصري",
    duration: "25 دقيقة",
    completed: false,
  },
  {
    id: 4,
    title: "تطوير الذاكرة العاملة",
    duration: "20 دقيقة",
    completed: false,
  },
  {
    id: 5,
    title: "تمارين عملية وتطبيقية",
    duration: "30 دقيقة",
    completed: false,
  },
]

export function CurriculumSection({ onBack }: CurriculumSectionProps) {
  return (
    <section className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-6 gap-2 text-muted-foreground hover:text-foreground"
        >
          <ArrowRight className="w-4 h-4" />
          العودة للمستويات
        </Button>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
              <Blocks className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm text-primary font-medium">المستوى الأول</p>
              <h1 className="font-[var(--font-heading)] text-2xl sm:text-3xl font-bold text-foreground">
                البناء الأساسي
              </h1>
            </div>
          </div>
          <p className="text-muted-foreground leading-relaxed">
            مرحباً بك في المستوى الأول! هنا ستتعلم الأساسيات مع استراتيجيات مصممة خصيصاً
            لدعم طريقتك الفريدة في التفكير والتعلم.
          </p>
        </div>

        {/* Lessons List */}
        <div className="mb-8">
          <h2 className="font-[var(--font-heading)] text-xl font-bold text-foreground mb-4">
            محتوى الدروس
          </h2>
          <div className="space-y-3">
            {lessons.map((lesson, index) => (
              <Card key={lesson.id} className="border border-border hover:border-primary/30 transition-colors">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    {lesson.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    ) : (
                      <span className="font-[var(--font-heading)] text-sm font-bold text-primary">
                        {index + 1}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground mb-1">{lesson.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {lesson.duration}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Reader Mode Content */}
        <div className="bg-card rounded-2xl border border-border p-6 sm:p-10">
          <div className="prose prose-lg max-w-none">
            <div className="flex items-center gap-3 mb-6">
              <BookOpen className="w-6 h-6 text-primary" />
              <h2 className="font-[var(--font-heading)] text-xl font-bold text-foreground m-0">
                الدرس الأول: مقدمة في التعلم التكيفي
              </h2>
            </div>

            <div className="space-y-6 text-foreground leading-[1.8] text-lg">
              <p>
                مرحباً بك في رحلة التعلم التكيفي! في هذا الدرس سنتعرف على مفهوم التعلم
                التكيفي وكيف يمكن أن يساعدك في تحقيق أهدافك التعليمية بطريقة تناسب
                قدراتك المعرفية الفريدة.
              </p>

              <div className="bg-secondary/10 rounded-xl p-6 border border-secondary/20">
                <h3 className="font-[var(--font-heading)] text-lg font-bold text-secondary mb-3">
                  ما هو التعلم التكيفي؟
                </h3>
                <p className="text-muted-foreground m-0">
                  التعلم التكيفي هو نهج تعليمي يراعي الفروق الفردية بين المتعلمين.
                  بدلاً من تقديم محتوى موحد للجميع، يتم تخصيص المحتوى والطريقة
                  بناءً على احتياجاتك وقدراتك المعرفية.
                </p>
              </div>

              <h3 className="font-[var(--font-heading)] text-lg font-bold text-foreground">
                لماذا التعلم التكيفي مهم؟
              </h3>

              <p>
                كل شخص يتعلم بطريقة مختلفة. البعض يتعلم بشكل أفضل من خلال الصور
                والرسوم، بينما يفضل آخرون النصوص والشروحات اللفظية. في بنية، نؤمن
                بأن فهم نمط تفكيرك الخاص هو الخطوة الأولى نحو تعلم أكثر فعالية.
              </p>

              <div className="bg-primary/5 rounded-xl p-6 border border-primary/20">
                <h3 className="font-[var(--font-heading)] text-lg font-bold text-primary mb-3">
                  تذكر دائماً
                </h3>
                <p className="text-muted-foreground m-0">
                  لا يوجد نمط تفكير &quot;صحيح&quot; أو &quot;خاطئ&quot;. كل نمط له نقاط قوته الخاصة،
                  وهدفنا مساعدتك على اكتشاف واستثمار نقاط قوتك بأفضل طريقة ممكنة.
                </p>
              </div>

              <h3 className="font-[var(--font-heading)] text-lg font-bold text-foreground">
                ما الذي ستتعلمه في هذا المستوى؟
              </h3>

              <ul className="space-y-3 list-none pr-0">
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-secondary mt-1 flex-shrink-0" />
                  <span>فهم أنماط التفكير المختلفة وكيفية التعرف على نمطك الخاص</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-secondary mt-1 flex-shrink-0" />
                  <span>استراتيجيات بديلة للتخيل البصري تناسب طريقتك في التفكير</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-secondary mt-1 flex-shrink-0" />
                  <span>تمارين عملية لتطوير الذاكرة العاملة والوظائف التنفيذية</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-secondary mt-1 flex-shrink-0" />
                  <span>أدوات ونصائح لتطبيق ما تعلمته في حياتك اليومية</span>
                </li>
              </ul>

              <p>
                خذ وقتك في استيعاب المحتوى، ولا تتردد في العودة لأي درس عندما تحتاج.
                التعلم رحلة، وليس سباقاً!
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="mt-8 flex justify-end">
          <Button className="gap-2 bg-primary hover:bg-primary/90">
            الدرس التالي
            <ArrowRight className="w-4 h-4 rotate-180" />
          </Button>
        </div>
      </div>
    </section>
  )
}
